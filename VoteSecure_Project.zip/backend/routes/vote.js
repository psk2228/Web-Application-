const router = require("express").Router();
const Candidate = require("../models/Candidate");
const User = require("../models/User");
const auth = require("../middleware/auth");

router.get("/", async (req,res)=>{
  const data = await Candidate.find();
  res.json(data);
});

router.post("/:id", auth, async (req,res)=>{
  const user = await User.findById(req.user.id);
  if(user.hasVoted) return res.json("Already voted");

  const candidate = await Candidate.findById(req.params.id);
  candidate.votes += 1;
  await candidate.save();

  user.hasVoted = true;
  await user.save();

  res.json("Vote counted");
});

module.exports = router;
