const router = require("express").Router();
const Candidate = require("../models/Candidate");

router.post("/add", async (req,res)=>{
  const candidate = new Candidate({name:req.body.name});
  await candidate.save();
  res.json("Candidate added");
});

router.get("/results", async (req,res)=>{
  const data = await Candidate.find();
  res.json(data);
});

module.exports = router;
