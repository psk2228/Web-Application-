import {useEffect,useState} from "react";
import axios from "axios";

export default function Vote(){
  const [candidates,setCandidates] = useState([]);

  useEffect(()=>{
    axios.get("http://localhost:5000/api/vote")
    .then(res=>setCandidates(res.data));
  },[]);

  const vote = async(id)=>{
    const token = localStorage.getItem("token");
    await axios.post(`http://localhost:5000/api/vote/${id}`,{},{
      headers:{Authorization:token}
    });
    alert("Voted!");
  };

  return(
    <div>
      <h2>Vote</h2>
      {candidates.map(c=>(
        <div key={c._id}>
          {c.name}
          <button onClick={()=>vote(c._id)}>Vote</button>
        </div>
      ))}
    </div>
  );
}
