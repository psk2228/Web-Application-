import {useState,useEffect} from "react";
import axios from "axios";

export default function Admin(){
  const [name,setName] = useState("");
  const [data,setData] = useState([]);

  const add = async ()=>{
    await axios.post("http://localhost:5000/api/admin/add",{name});
    alert("Added");
  };

  useEffect(()=>{
    axios.get("http://localhost:5000/api/admin/results")
    .then(res=>setData(res.data));
  },[]);

  return(
    <div>
      <h2>Admin</h2>
      <input onChange={e=>setName(e.target.value)} />
      <button onClick={add}>Add Candidate</button>
      {data.map(c=>(
        <div key={c._id}>{c.name} - {c.votes}</div>
      ))}
    </div>
  );
}
