import {BrowserRouter,Routes,Route} from "react-router-dom";
import Login from "./Login";
import Register from "./Register";
import Vote from "./Vote";
import Admin from "./Admin";

function App(){
  return(
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/vote" element={<Vote/>}/>
        <Route path="/admin" element={<Admin/>}/>
      </Routes>
    </BrowserRouter>
  );
}
export default App;
